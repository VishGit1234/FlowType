import Login from "./login"
import Login_2 from "./login_2"
import Typer from "./components/typer"
export default function Home(){
  return(
      <Login_2/>
    
  )
}